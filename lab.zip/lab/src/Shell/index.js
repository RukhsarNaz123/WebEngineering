import React, {useState} from 'react';
import { useSelector, useDispatch } from 'react-redux';
import List from '@mui/material/List';
import Button from '@mui/material/Button';
import Student from '../student/Student';
import Container from '@mui/material/Container';
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';
import StudentDetail from '../student/studentSlice'
import { styled } from '@mui/material/styles';
import Input from '@mui/material/Input';
import FormControl from '@mui/material/FormControl';
import Paper from '@mui/material/Paper';
import TextField from '@mui/material/TextField';
import Typography from '@mui/material/Typography';
import Modal from '@mui/material/Modal';
import {
    addStudent
  } from "../student/studentSlice";
import './index.css'

const Item = styled(Paper)(({ theme }) => ({
    ...theme.typography.body2,
    padding: theme.spacing(1),
    textAlign: 'center',
    color: theme.palette.text.secondary,
  }));

  
const style = {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: 400,
    bgcolor: 'background.paper',
    border: '2px solid #000',
    boxShadow: 24,
    p: 4,
  };
export default function AlignItemsList() {
    const dispatch = useDispatch();
    const [open, setOpen] = React.useState(false);
    const [name, setName] = useState("");
    const [description, setDescription] = useState("");
    const [rollNo, setRollNo] = useState("");
    const emptyField=()=>{
        setName("")
        setRollNo("")
        setDescription("")
    }
    const handleOpen = () =>{
        setOpen(true);
        emptyField()
    }
    const handleClose = () => setOpen(false);

    const studentList=useSelector(state=>state.student.studentList)
    const addStudentFun=()=>{
        dispatch(addStudent({name:name, roll: rollNo, description, description}))
        emptyField()
    }
    console.log(name)
  return (
      <Container>
        <List sx={{ width: '100%', maxWidth: 360, bgcolor: 'background.paper' }}>
        {studentList.map((value)=>{
            return(
                <>
                   <Student name={value.name} roll={value.roll} description={value.description}/>
                </>
            )
        })}
      
      
        </List>
        <Button variant="contained" onClick={handleOpen}>Add</Button>
        <div>
        <Modal
            open={open}
            onClose={handleClose}
            aria-labelledby="modal-modal-title"
            aria-describedby="modal-modal-description"
        >
            <>
            <Box sx={style}>
            <Typography id="modal-modal-title" variant="h6" component="h2">
                Add Student
            </Typography>
            <Grid container>
                <Grid item xs={24}>
                <FormControl variant="standard" sx={{ m: 1, mt: 3, width: '25ch' }}>
                <Typography id="modal-modal-title" variant="h6" component="h6">
                Name
            </Typography>
                <Input
                    id="standard-adornment-weight"
                    value={name}
                    
                    onChange={(e)=>setName(e.target.value )}
                    aria-describedby="standard-weight-helper-text"
                    inputProps={{
                    'aria-label': 'weight',
                    }}
                />
                <Typography id="modal-modal-title" variant="h6" component="h6">
                Roll No
            </Typography>
                 <Input
                    id="standard-adornment-weight"
                    value={rollNo}
                    
                    onChange={(e)=>setRollNo(e.target.value )}
                    aria-describedby="standard-weight-helper-text"
                    inputProps={{
                    'aria-label': 'weight',
                    }}
                />
                <Typography id="modal-modal-title" variant="h6" component="h6">
                Description
            </Typography>
                <Input
                    id="standard-adornment-weight"
                    value={description}
                    
                    onChange={(e)=>setDescription(e.target.value )}
                    aria-describedby="standard-weight-helper-text"
                    inputProps={{
                    'aria-label': 'weight',
                    }}
                />
          {/* <FormHelperText id="standard-weight-helper-text">Weight</FormHelperText> */}
        </FormControl>
                </Grid>
            <Button variant="contained" onClick={addStudentFun}>Submit</Button>
            </Grid>
            </Box>
            </>
        </Modal>
        </div>
        
        </Container>
        
  );
}